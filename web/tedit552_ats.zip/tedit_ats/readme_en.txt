TEDIT, v4.11


Install:
1. In main config.cfg of the game parameter g_save_format should be "2"!
2. All files except all folders put in your savegame folder.

Most of help you can read in the program by pressing F1 key.
You can also see some help videos from Video folder.

The Mods folder contains mods needed for fully work of the program:
 - tedit_notebook_ats.scs - modified notebook for American Truck Simulator
 - tedit_notebook_ets.scs - modified notebook for Euro Truck Simulator 2
 - tedit_system_font.scs - changed system font for console (for ATS and ETS2).
Place the necessary files into your "mod" folder.
 
The Plugins folder contains plugin needed for fully work of the program.
This plugin needs to interact with the program directly from the game.
The plugin is in two variants - for x86 and for x64.
Copy entire bin folder into the folder where game is installed:
...\Euro Truck Simulator 2\ or ...\American Truck Simulator\.

Note: gps.txt file contains coordinates of default bases + East + Scandinavia + France for ETS2 v1.26!
TEDIT files adapted for American Truck Simulator will be later!


Copyright � 2017 by Alex (Knox_xss)
